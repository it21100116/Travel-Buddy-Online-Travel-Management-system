# TravelBuddy
A travel agency web based software where people can book hotels and drivers with cars and hotels can publish their accomadation details.

install nodeJS
goto backend and perform npm i (node installation)
goto frontend and perform npm i (node installation)

goto the frontend and perform npm start to run the frontend
goto the backend and perform npm run dev to run the backend

