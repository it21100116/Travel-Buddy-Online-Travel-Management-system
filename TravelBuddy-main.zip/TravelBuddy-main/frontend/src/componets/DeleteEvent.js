
// import React,{useState,useEffect} from 'react';
// import axios from "axios";
// import { useLocation } from "react-router-dom";



// function DeleteEvent (){

//     const location = useLocation(); //
//     console.log(location);
//     const id= location.pathname.split("/")[2];
//     console.log(id);
    

//         //input any authentications are needed
//         //(path,function needed to execute)
//         axios.delete(`http://localhost:8070/event/delete/${id}`).then(()=>{
//             alert("Event deleted")
            

//         }).catch((err)=>{
//             alert(err)
//         })



//         return (
//             <div>
//               <h3>  event deleted </h3>
//             </div>  
//           );
       
//     }

    
      
    

// export default DeleteEvent;