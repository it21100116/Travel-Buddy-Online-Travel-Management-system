import React from "react";
function LocationDi1 () {

    return(
      <div>
      <br />
     <nav className= "navbar">
  <a className="navbar-brand"><h1 className="Ma"><b>&nbsp;&nbsp;&nbsp; &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
  &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    ~~P E A C E  &nbsp;&nbsp;&nbsp;   P A G O D A ~~</b></h1></a>
  </nav>
<br/>
<div><center>
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
  </ol>
  <div class="carousel-inner">
    <div class="carousel-item active">
      <img class="d-block w-100" src="images/1.jpg" alt="First slide"/>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/15.jpg" alt="Second slide"/>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="images/16.jpg" alt="Third slide"/>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div></center>
</div>

<br/><br/>

<div>
  <p className="Para"><h5>&nbsp;&nbsp; Hidden amongst the trees of the Unawatuna rainforests and yet visible across the water from the historic Galle Fort in the Bay of 
    Galle is the “Sama Ceitya”, <br/><br/>&nbsp;&nbsp; one of four Japanese Peace Pagodas that can be found in Sri Lanka. Situated on Rummasala Hill, it was 
    built with the assistance of Japanese Buddhist monks in 2005 <br/><br/>&nbsp;&nbsp; (when Sri Lanka was still in the midst of fighting a devastating civil war) as 
    part of a plan to build temples of peace in conflict zones. </h5></p><br/><br/><br/>
</div>

<center><button type="button" class="btn btn-secondary btn-lg">&nbsp;&nbsp; Add To Favorite &nbsp;&nbsp; </button></center>

<br/><br/><br/><br/>

</div>
    )
}

export default LocationDi1;